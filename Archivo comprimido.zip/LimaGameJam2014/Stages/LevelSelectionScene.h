#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface LevelSelectionScene : CCScene {
    
}

+ (LevelSelectionScene *)scene;
- (id)init;

@end
