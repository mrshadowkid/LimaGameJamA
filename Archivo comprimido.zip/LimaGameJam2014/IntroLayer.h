//
//  IntroLayer.h
//  LimaGameJam2014
//
//  Created by DSBMobile on 25/01/14.
//  Copyright LimaGameJam 2014. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface IntroLayer : CCLayer
{
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
