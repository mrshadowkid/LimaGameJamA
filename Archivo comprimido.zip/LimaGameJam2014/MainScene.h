#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface MainScene : CCScene {
    
}

+ (CCScene *)scene;
- (id)init;

@end
