//
//  main.m
//  LimaGameJam2014
//
//  Created by DSBMobile on 25/01/14.
//  Copyright LimaGameJam 2014. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
    [pool release];
    return retVal;
}
